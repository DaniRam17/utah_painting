package com.utahpainting17

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
